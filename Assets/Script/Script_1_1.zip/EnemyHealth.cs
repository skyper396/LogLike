using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int maxHp = 10;

    [SerializeField]
    private int currentHp;

    private void Start()
    {
        currentHp = maxHp;
        Debug.Log($"{gameObject.name} ü�� : {currentHp}");
    }

    public void TakeDamage(int damage)
    {
        currentHp -= damage;

        Debug.Log(
            $"{gameObject.name} ���� {damage} / ���� ü�� {currentHp}"
        );

        if (currentHp <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Debug.Log($"{gameObject.name} ���");

        Destroy(gameObject);
    }
}