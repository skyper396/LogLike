using UnityEngine;

public class PlayerHealth : MonoBehaviour
{
    public int maxHp = 100;

    [SerializeField]
    private int currentHp;

    private void Start()
    {
        currentHp = maxHp;

        Debug.Log($"�÷��̾� ü�� : {currentHp}");
    }

    public void TakeDamage(int damage)
    {
        currentHp -= damage;

        if (currentHp < 0)
        {
            currentHp = 0;
        }

        Debug.Log(
            $"�÷��̾� ���� {damage} / ���� ü�� {currentHp}"
        );

        if (currentHp <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Debug.Log("�÷��̾� ���");
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            TakeDamage(10);
        }
    }
}